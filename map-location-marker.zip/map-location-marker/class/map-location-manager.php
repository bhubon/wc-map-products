<?php
class Map_Location_Manager {
    public function __construct() {
        add_action('admin_menu', [$this, 'mlm_create_map_manager_menu']);
        add_action('admin_enqueue_scripts', [$this, 'mlm_assets']);

        add_action('wp_ajax_mlm_submit_address', [$this, 'mlm_submit_address']);
        add_action('wp_ajax_nopriv_mlm_submit_address', [$this, 'mlm_submit_address']);

        add_action('wp_ajax_marker_filter', [$this, 'marker_filter']);
        add_action('wp_ajax_nopriv_marker_filter', [$this, 'marker_filter']);

        add_action('wp_ajax_mlm_search_query', [$this, 'mlm_search_query']);
        add_action('wp_ajax_nopriv_mlm_search_query', [$this, 'mlm_search_query']);

        add_action('wp_ajax_get_address_by_id', [$this, 'get_address_by_id']);
        add_action('wp_ajax_nopriv_get_address_by_id', [$this, 'get_address_by_id']);

        add_action('wp_ajax_delete_address', [$this, 'delete_address']);
        add_action('wp_ajax_nopriv_delete_address', [$this, 'delete_address']);

        add_action('admin_enqueue_scripts', [$this,'mlm_load_media_files']);
    }
    public function mlm_create_map_manager_menu() {
        add_menu_page(
            __('Adressdaten', 'map-location-marker'),
            __('Adressdaten', 'map-location-marker'),
            'manage_options',
            'map-address-manager',
            [$this, 'mlm_map_menu_body'],
            'dashicons-location-alt'
        );
    }
    public function mlm_map_menu_body() {
        global $wpdb;
        $locations = $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM {$wpdb->prefix}mlm_map_manager")
        );

        foreach ($locations as $location) {
            // echo "<pre>";
            // print_r($location->id);
        }
        require_once plugin_dir_path(__FILE__) . 'map-manager-body.php';
        ob_get_contents();
    }
    public function mlm_assets() {
        wp_enqueue_style('mlm-main-css', plugins_url('../assets/css/main.css', __FILE__), [], '1.0');
        wp_enqueue_script('mlm-main-js', plugins_url('../assets/js/main.js', __FILE__), ['jquery'], '1.01', true);
        wp_localize_script('mlm-main-js', 'mlm_object', [
            'ajax_url' => admin_url('admin-ajax.php'),
        ]);
    }
    // ajax
    public function mlm_submit_address() {
        $msg = [];

        if (isset($_POST) && isset($_POST['action']) && $_POST['action'] == 'mlm_submit_address') {
            global $wpdb;

            if (empty($_POST['f_name']) || empty($_POST['l_name'])  || empty($_POST['address']) || empty($_POST['zip_code']) || empty($_POST['landline']) || empty($_POST['mobile']) || empty($_POST['email']) || empty($_POST['images']) || empty($_POST['latitude']) || empty($_POST['longitude']) || empty($_POST['radius'])) {
                $msg['msg'] = "All Field Required";
                $msg['status'] = false;
            } else {
                if (isset($_POST['mode']) && $_POST['mode'] == 'edit') {
                    $data = [];
                    $data['address_id'] = sanitize_text_field($_POST['address_id']);
                    $data['f_name'] = sanitize_text_field($_POST['f_name']);
                    $data['l_name'] = sanitize_text_field($_POST['l_name']);
                    $data['company_name'] = sanitize_text_field($_POST['company_name']);
                    $data['address'] = sanitize_text_field($_POST['address']);
                    $data['zip_code'] = sanitize_text_field($_POST['zip_code']);
                    $data['landline'] = sanitize_text_field($_POST['landline']);
                    $data['mobile'] = sanitize_text_field($_POST['mobile']);
                    $data['email'] = sanitize_text_field($_POST['email']);
                    $data['link'] = sanitize_text_field($_POST['link']);
                    $data['images'] = sanitize_text_field($_POST['images']);
                    $data['latitude'] = sanitize_text_field($_POST['latitude']);
                    $data['longitude'] = sanitize_text_field($_POST['longitude']);
                    $data['radius'] = sanitize_text_field($_POST['radius']);
                    $data['radius'] = $data['radius'];
                    $data['note'] = sanitize_text_field($_POST['note']);
                    $data['image_selector'] = sanitize_text_field($_POST['image_selector']);
                    if (isset($_POST['color'])) {
                        $data['color'] = sanitize_text_field($_POST['color']);
                    } else {
                        $data['color'] = '';
                    }

                    $update = $wpdb->update(
                        $wpdb->prefix . 'mlm_map_manager',
                        array(
                            'f_name' => $data['f_name'],
                            'l_name' => $data['l_name'],
                            'company_name' => $data['company_name'],
                            'address' => $data['address'],
                            'zip_code' => $data['zip_code'],
                            'landline' => $data['landline'],
                            'mobile' => $data['mobile'],
                            'email' => $data['email'],
                            'link' => $data['link'],
                            'image' => $data['images'],
                            'color' => $data['color'],
                            'img_src' => $data['image_selector'],
                            'radius' => $data['radius'],
                            'notes' => $data['note'],
                            'latitude' => $data['latitude'],
                            'longitude' => $data['longitude'],
                        ),
                        array('ID' => $data['address_id']),
                        array(
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                        ),
                        array('%d'),
                    );

                    if ($update) {
                        $msg['msg'] = 'Successfully Updated';
                        $msg['status'] = true;
                    } else {
                        $msg['msg'] = 'Something Went Wrong';
                        $msg['status'] = false;
                    }
                } else {

                    $data = [];
                    $data['f_name'] = sanitize_text_field($_POST['f_name']);
                    $data['l_name'] = sanitize_text_field($_POST['l_name']);
                    $data['company_name'] = sanitize_text_field($_POST['company_name']);
                    $data['address'] = sanitize_text_field($_POST['address']);
                    $data['zip_code'] = sanitize_text_field($_POST['zip_code']);
                    $data['landline'] = sanitize_text_field($_POST['landline']);
                    $data['mobile'] = sanitize_text_field($_POST['mobile']);
                    $data['email'] = sanitize_text_field($_POST['email']);
                    $data['link'] = sanitize_text_field($_POST['link']);
                    $data['images'] = sanitize_text_field($_POST['images']);
                    $data['latitude'] = sanitize_text_field($_POST['latitude']);
                    $data['longitude'] = sanitize_text_field($_POST['longitude']);
                    $data['radius'] = sanitize_text_field($_POST['radius']);
                    $data['radius'] = $data['radius'];
                    $data['note'] = sanitize_text_field($_POST['note']);
                    $data['image_selector'] = sanitize_text_field($_POST['image_selector']);
                    if (isset($_POST['color'])) {
                        $data['color'] = sanitize_text_field($_POST['color']);
                    } else {
                        $data['color'] = '';
                    }
                    // echo "<pre>";
                    // print_r($_POST);
                    // print_r($data);

                    $insert = $wpdb->insert(
                        $wpdb->prefix . 'mlm_map_manager',
                        array(
                            'f_name' => $data['f_name'],
                            'l_name' => $data['l_name'],
                            'company_name' => $data['company_name'],
                            'address' => $data['address'],
                            'zip_code' => $data['zip_code'],
                            'landline' => $data['landline'],
                            'mobile' => $data['mobile'],
                            'email' => $data['email'],
                            'link' => $data['link'],
                            'image' => $data['images'],
                            'color' => $data['color'],
                            'img_src' => $data['image_selector'],
                            'radius' => $data['radius'],
                            'notes' => $data['note'],
                            'latitude' => $data['latitude'],
                            'longitude' => $data['longitude'],
                        ),
                        array(
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                            '%s',
                        )
                    );

                    if ($insert) {
                        $msg['msg'] = 'Successfully Inserted';
                        $msg['status'] = true;
                    } else {
                        $msg['msg'] = 'Something Went Wrong';
                        $msg['status'] = false;
                    }
                }
            }
        } else {
            $msg['msg'] = 'Something Went Wrong';
            $msg['status'] = false;
        }
        wp_send_json($msg);
        die();
    }
    // marker filter 
    public function marker_filter() {
        $html = '';
        if (isset($_POST) && isset($_POST['action']) && $_POST['action'] == 'marker_filter') {
            global $wpdb;
            $lat = sanitize_text_field($_POST['lat']);
            $lng = sanitize_text_field($_POST['lng']);
            $table = $wpdb->prefix . 'mlm_map_manager';
            $addresses = $wpdb->get_results("SELECT * FROM {$table} WHERE latitude={$lat} AND longitude={$lng} ORDER BY id DESC");
            if (!is_wp_error($addresses) && $addresses) {

                foreach ($addresses as $address) {
                    $html .= '<div class="address-detail-item">
                    <div class="item-wrapper">
                        <div class="addres-detail-item-divide">
                            <p>EventBrite: ' . esc_html($address->f_name) . '</p>
                            <p>Nachname: ' . esc_html($address->l_name) . '</p>
                            <p>Adresse: ' . esc_html($address->address) . '</p>
                            <p>PLZ: ' . esc_html($address->zip_code) . '</p>
                            <p>Radius: ' . esc_html($address->radius) . '&nbsp;K.M</p>
                            <p>Firmen Name: ' . esc_html($address->company_name) . '</p>
                        </div>
                        <div class="addres-detail-item-divide">
                            <p>Festnetz-Nr: ' . esc_html($address->landline) . '</p>
                            <p>Mobile-Nr: ' . esc_html($address->mobile) . '</p>
                            <p>E-Mail: ' . esc_html($address->email) . '</p>
                            <p>Formular-Link: <a href="' . esc_url($address->link) . '" target="_blank">' . esc_html($address->link) . '</a></p>
                            <p>Notiz: ' . esc_html($address->notes) . '</p>
                        </div>
                        <div class="addres-detail-item-divide">
                            <p><a href="javascript::void(0);" onclick="getAddressData(' . esc_html($address->id) . ')" class="edit-address_' . esc_html($address->id) . '" >Bearbeiten</a></p>
                            <p><a href="javascript::void(0);" onclick="deleteAddress(' . esc_html($address->id) . ')" class="delete-address_' . esc_html($address->id) . '">Löschen</a></p>
                        </div>
                    </div>
                </div>';
                }
            } else {
                $html .= "<h4 style='text-align:center;'>keine Daten gefunden </h4>";
            }
        } else {
            $html .= "<h4 style='text-align:center;'>Something Went Wront!</h4>";
        }
        wp_send_json($html);
        die();
    }
    // search
    public function mlm_search_query() {
        $html = '';
        if (isset($_POST) && isset($_POST['action']) && $_POST['action'] == 'mlm_search_query') {
            global $wpdb;
            $query = sanitize_text_field($_POST['query']);
            $table = $wpdb->prefix . 'mlm_map_manager';
            $addresses = $wpdb->get_results("SELECT * FROM {$table} WHERE f_name LIKE '%{$query}%' OR l_name LIKE '%{$query}%' OR zip_code LIKE '%{$query}%' OR address LIKE '%{$query}%' ORDER BY id DESC ");

            if (!is_wp_error($addresses) && $addresses ) {
                foreach ($addresses as $address) {
                    $html .= '<div class="address-detail-item">
                    <div class="item-wrapper">
                        <div class="addres-detail-item-divide">
                            <p>Vorname: ' . esc_html($address->f_name) . '</p>
                            <p>Nachname: ' . esc_html($address->l_name) . '</p>
                            <p>Adresse: ' . esc_html($address->address) . '</p>
                            <p>PLZ: ' . esc_html($address->zip_code) . '</p>
                            <p>Radius: ' . esc_html($address->radius) . '&nbsp;K.M</p>
                            <p>Firmen Name: ' . esc_html($address->company_name) . '</p>
                        </div>
                        <div class="addres-detail-item-divide">
                            <p>Festnetz-Nr: ' . esc_html($address->landline) . '</p>
                            <p>Mobile-Nr: ' . esc_html($address->mobile) . '</p>
                            <p>E-Mail: ' . esc_html($address->email) . '</p>
                            <p>Formular-Link: <a href="' . esc_url($address->link) . '" target="_blank">' . esc_html($address->link) . '</a></p>
                            <p>Notiz: ' . esc_html($address->notes) . '</p>
                        </div>
                        <div class="addres-detail-item-divide">
                        <p><a href="javascript::void(0);" onclick="getAddressData(' . esc_html($address->id) . ')" class="edit-address_' . esc_html($address->id) . '" >Bearbeiten</a></p>
                        <p><a href="javascript::void(0);" onclick="deleteAddress(' . esc_html($address->id) . ')" class="delete-address_' . esc_html($address->id) . '">Löschen</a></p>
                        </div>
                    </div>
                </div>';
                }
            } else {
                $html .= "<h4 style='text-align:center;'>keine Daten gefunden </h4>";
            }
        } else {
            $html .= "<h4 style='text-align:center;'>Something Went Wront!</h4>";
        }
        wp_send_json($html);
        die();
    }

    // get_address_by_id
    public function get_address_by_id() {
        $data = [];
        if (isset($_POST) && $_POST['action'] == 'get_address_by_id') {
            global $wpdb;
            $address_id = sanitize_text_field($_POST['address_id']);
            $table = $wpdb->prefix . 'mlm_map_manager';
            $addresses = $wpdb->get_results("SELECT * FROM {$table} WHERE id={$address_id} LIMIT 1");
            if (!is_wp_error($addresses)) {
                $data['id'] = $addresses[0]->id;
                $data['f_name'] = $addresses[0]->f_name;
                $data['l_name'] = $addresses[0]->l_name;
                $data['address'] = $addresses[0]->address;
                $data['address'] = $addresses[0]->address;
                $data['zip_code'] = $addresses[0]->zip_code;
                $data['landline'] = $addresses[0]->landline;
                $data['mobile'] = $addresses[0]->mobile;
                $data['email'] = $addresses[0]->email;
                $data['link'] = $addresses[0]->link;
                $data['image'] = $addresses[0]->image;
                $data['color'] = $addresses[0]->color;
                $data['image_selector'] = $addresses[0]->img_src;
                $data['radius'] = $addresses[0]->radius;
                $data['latitude'] = $addresses[0]->latitude;
                $data['longitude'] = $addresses[0]->longitude;
                $data['company_name'] = $addresses[0]->company_name;
                $data['notes'] = $addresses[0]->notes;
            } else {
                $data['msg'] = 'Something went wrong!';
            }
        } else {
            $data['msg'] = 'Something went wrong!';
        }

        wp_send_json($data);
        die();
    }
    // delete address
    public function delete_address() {
        $msg = [];
        if (isset($_POST) && isset($_POST['action']) && $_POST['action'] == 'delete_address') {
            global $wpdb;
            $address_id = sanitize_text_field($_POST['id']);
            $delete = $wpdb->delete($wpdb->prefix . 'mlm_map_manager', array('ID' => $address_id), array('%d'));
            if (!is_wp_error($delete)) {
                $msg['msg'] = "Successfully Deleted";
                $msg['status'] = true;
            } else {
                $msg['msg'] = "Something Went Wrong";
                $msg['status'] = false;
            }
        } else {
            $msg['msg'] = "Something Went Wrong";
            $msg['status'] = false;
        }
        wp_send_json($msg);
        die();
    }

    // media selector
    function mlm_load_media_files() {
        wp_enqueue_media();
    }
    
}
