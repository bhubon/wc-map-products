<div class="wrap">
    <h1><?php _e('Adress Manager', 'map-location-marker') ?></h1>
    <div class="address-manager-wrap">
        <div class="address-manager-head">
            <div class="address-manager-head-wrap">
                <form id="address_form">
                    <div class="input-group">
                        <div class="input-items">
                            <label for="f_name"><?php _e("Vorname", TEXTDOMAIN) ?></label>
                            <input type="text" name="f_name" id="f_name" placeholder="<?php _e("Vorname", TEXTDOMAIN) ?>" class="input-text">
                        </div>
                        <div class="input-items">
                            <label for="f_name"><?php _e("Nachname", TEXTDOMAIN) ?></label>
                            <input type="text" name="l_name" id="l_name" placeholder="<?php _e("Nachname", TEXTDOMAIN) ?>" class="input-text">
                        </div>
                        <div class="input-items">
                            <label for="company_name"><?php _e("Firmen Name", TEXTDOMAIN) ?></label>
                            <input type="text" name="company_name" id="company_name" placeholder="<?php _e("Firmen Name", TEXTDOMAIN) ?>" class="input-text">
                        </div>
                        <div class="input-items">
                            <label for="address"><?php _e("Adresse", TEXTDOMAIN) ?></label>
                            <input type="text" role="presentation" autocomplete="off" name="address" id="address" placeholder="<?php _e("Adresse", TEXTDOMAIN) ?>" class="input-text">
                        </div>
                        <div class="input-items">
                            <label for="zip_code"><?php _e("PLZ", TEXTDOMAIN) ?></label>
                            <input type="text" name="zip_code" id="zip_code" placeholder="<?php _e("PLZ", TEXTDOMAIN) ?>" class="input-text">
                        </div>
                        <div class="input-items">
                            <label for="landline "><?php _e("Festnetz-Nr. ", TEXTDOMAIN) ?></label>
                            <input type="text" name="landline" id="landline" placeholder="<?php _e("Festnetz-Nr. ", TEXTDOMAIN) ?>" class="input-text">
                        </div>
                        <div class="input-items">
                            <label for="mobile"><?php _e("Mobile-Nr.", TEXTDOMAIN) ?></label>
                            <input type="text" name="mobile" id="mobile" placeholder="<?php _e("Mobile-Nr.", TEXTDOMAIN) ?>" class="input-text">
                        </div>
                        <div class="input-items">
                            <label for="email"><?php _e("E-Mail ", TEXTDOMAIN) ?></label>
                            <input type="email" name="email" id="email" placeholder="<?php _e("E-Mail ", TEXTDOMAIN) ?>" class="input-text">
                        </div>
                    </div>
                    <div class="input-group-2">
                        <div class="input-items">
                            <label for="images"><?php _e("Symbol wählen", TEXTDOMAIN) ?></label><br>
                            <select name="images" id="images">
                                <option value="image"><?php _e('Image', TEXTDOMAIN); ?></option>
                                <option value="pin.png"><?php _e('Pin', TEXTDOMAIN); ?></option>
                            </select>
                        </div>
                        <div class="input-items" id="color_picker_wrap">
                            <label for="color_picker"><?php _e("Icon farbe", TEXTDOMAIN) ?></label>
                            <input type="color" name="color" id="color_picker">
                        </div>
                        <div class="input-items" id="image_picker">
                            <label for="custom_image"><?php _e("", TEXTDOMAIN) ?></label>
                            <a href="#" id="img-upload"><?php _e("Icon auswählen", TEXTDOMAIN) ?></a><br>
                            <img src="#" id="img-src" width="32px" style="margin-top: 10px;display:none;">
                            <input type="hidden" name="image_selector" id="image_selector">
                        </div>
                        <div class="input-items">
                            <label for="radius"><?php _e("Radius km", TEXTDOMAIN) ?></label>
                            <input type="number" name="radius" id="radius" placeholder="In K.M">
                        </div>
                        <div class="input-items">
                            <label for="link"><?php _e("Formular-Link", TEXTDOMAIN) ?></label>
                            <input type="url" name="link" id="link" placeholder="Formular-Link">
                        </div>
                        <div class="input-items">
                            <label for="note"><?php _e("Note", TEXTDOMAIN) ?></label><br>
                            <textarea name="note" id="note" cols="25" rows="2"></textarea>
                        </div>
                    </div>
                    <input type="hidden" name="latitude" id="latitude" class="input-text">
                    <input type="hidden" name="longitude" id="longitude" class="input-text">
                    <input type="hidden" name="action" id="action" value="mlm_submit_address">
                    <div class="input-extra">
                        <button type="submit" id="address_submit_btn" class="button button-primary button-large">Übertragen</button>
                    </div>
                </form>
                <p class="address-alert"></p>
            </div>
        </div>
        <div class="address-manager-body">
            <div class="address-body-part">
                <div class="address-details">
                    <div class="heading">
                        <h4><?php _e("Adress Details", TEXTDOMAIN); ?></h4>
                        <p><input type="search" placeholder="Name, PLZ, Adresse" id="search_q">
                            <input type="button" class="button button-primary button-large" id="search_btn" value="Suchen">
                        </p>
                    </div>
                    <div class="address-details-body">
                        <div class="address-detail-items">
                            <?php
                            global $wpdb;
                            $items_per_page = 5;
                            $table = $wpdb->prefix . 'mlm_map_manager';

                            $total_query = "SELECT COUNT(1) FROM {$table}";
                            $total = $wpdb->get_var($total_query);
                            $page = isset($_GET['apage']) ? abs((int) $_GET['apage']) : 1;
                            $offset = ($page * $items_per_page) - $items_per_page;
                            // print_r($total);
                            $addresses = $wpdb->get_results("SELECT * FROM {$table} ORDER BY id DESC LIMIT ${offset}, ${items_per_page}");
                            if ($addresses) {
                                foreach ($addresses as $address) {
                            ?>
                                    <div class="address-detail-item">
                                        <div class="item-wrapper">
                                            <div class="addres-detail-item-divide">
                                                <p>Vorname: <?php echo esc_html($address->f_name); ?></p>
                                                <p>Nachname: <?php echo esc_html($address->l_name); ?></p>
                                                <p>Adresse: <?php echo esc_html($address->address); ?></p>
                                                <p>PLZ: <?php echo esc_html($address->zip_code); ?></p>
                                                <p>Radius: <?php echo esc_html($address->radius); ?>&nbsp;K.M</p>
                                                <p>Firmen Name: <?php echo esc_html($address->company_name); ?></p>
                                            </div>
                                            <div class="addres-detail-item-divide">
                                                <p>Festnetz-Nr.: <?php echo esc_html($address->landline); ?></p>
                                                <p>Mobile-Nr.: <?php echo esc_html($address->mobile); ?></p>
                                                <p>E-Mail : <?php echo esc_html($address->email); ?></p>
                                                <p>Formular-Link: <a href="<?php echo esc_url($address->link); ?>" target="_blank"><?php echo esc_html($address->link); ?></a></p>
                                                <p>Notiz: <?php echo esc_html($address->notes); ?></p>
                                            </div>
                                            <div class="addres-detail-item-divide">
                                                <!-- <p><a href="ajavscript::void(0);" class="mapper" data-lat="<?php echo $address->latitude; ?>" data-lng="<?php echo $address->longitude; ?>">See On Map</a></p> -->
                                                <p><a href="javascript::void(0);" onclick="getAddressData(<?php echo esc_html($address->id); ?>)" class="edit-address_<?php echo esc_html($address->id); ?>">Bearbeiten</a></p>
                                                <p><a href="javascript::void(0);" onclick="deleteAddress(<?php echo esc_html($address->id); ?>)" class="delete-address_<?php echo esc_html($address->id); ?>">Löschen</a></p>
                                            </div>
                                        </div>
                                    </div>
                            <?php

                                }
                            }else{
                                echo "<h2 style='text-align:center;'>keine Daten gefunden</h2>";
                            }
                            ?>
                        </div>
                        <div class="addres-details-pagination">
                            <?php
                            echo paginate_links(array(
                                'base' => add_query_arg('apage', '%#%'),
                                'format' => '',
                                'prev_text' => __('&laquo;'),
                                'next_text' => __('&raquo;'),
                                'total' => ceil($total / $items_per_page),
                                'current' => $page,
                                'type' => 'list',
                            ));
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="address-body-part">
                <?php
                $addresses = $wpdb->get_results("SELECT * FROM {$table} ORDER BY id DESC");
                $address_list = [];
                if ($addresses) {
                    foreach ($addresses as $address) {
                        array_push($address_list, $address);
                    }
                }
                ?>
                <div id="mlm_map"></div>
                <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyClC-sAzNv0gAIVd-Y7eQ4WjkUa1ZqUdpw&&libraries=places,drawing,geometry&callback=initMap" async defer></script>
                <script>
                    let map;


                    var myStyles = [{
                        featureType: "poi",
                        // elementType: "labels",
                        stylers: [{
                            visibility: "off"
                        }]
                    }];

                    function initMap() {
                        const map = new google.maps.Map(document.getElementById("mlm_map"), {
                            center: {
                                lat: 52.516266,
                                lng: 13.377775
                            },
                            zoom: 8,
                            mapTypeId: google.maps.MapTypeId.ROADMAP,
                            styles: myStyles
                        });
                        map.addListener("click", (mapsMouseEvent) => {
                            if (jQuery("#f_name").val() != '') {
                                // console.log(JSON.stringify(mapsMouseEvent.latLng.toJSON(), null, 2));
                                var mylatlong = mapsMouseEvent.latLng.toJSON();
                                jQuery("#latitude").val(mylatlong.lat);
                                jQuery("#longitude").val(mylatlong.lng);

                            }
                        });

                        const image =
                            "https://developers.google.com/maps/documentation/javascript/examples/full/images/beachflag.png";

                        function addMarker(coords, icon) {
                            const marker = new google.maps.Marker({
                                position: coords,
                                map,
                                icon: icon,
                            });
                            marker.addListener('click', function(mapsMouseEvent) {
                                console.log(coords);
                                // if (jQuery("#f_name").val() != '') {
                                // var mylatlong = mapsMouseEvent.latLng.toJSON();
                                // jQuery("#latitude").val(mylatlong.lat);
                                // jQuery("#longitude").val(mylatlong.lng);

                                // }
                                var mylatlong = mapsMouseEvent.latLng.toJSON();
                                var container = jQuery('.address-details-body');
                                var loader = jQuery(".lds-ring");
                                container.html('<div style="display:inline-block;" class="lds-ring"><div></div><div></div> <div></div> <div></div></div>');


                                var my_ajax_url = "<?php echo admin_url('admin-ajax.php') ?>";
                                var my_data = {
                                    lat: mylatlong.lat,
                                    lng: mylatlong.lng,
                                    action: 'marker_filter',
                                };

                                jQuery.post(my_ajax_url, my_data, function(response) {
                                    // console.log(response);
                                    // jQuery('.address-details-body').html(response);
                                    container.html(response);
                                    // loader.css("display", "none");
                                });

                                map.panTo(this.getPosition());
                                map.setZoom(13);
                            });
                        }

                        function svgIcon(color = "#D6493C") {
                            const svgMarker = {
                                path: "M 237 33.073 C 233.425 33.540, 227.236 34.646, 223.247 35.530 C 219.258 36.414, 211.835 38.486, 206.753 40.133 C 201.671 41.780, 192.559 45.596, 186.506 48.613 C 180.453 51.630, 171.417 57.006, 166.426 60.560 C 161.436 64.115, 153.919 70.280, 149.723 74.261 C 145.527 78.243, 138.875 85.550, 134.942 90.500 C 131.008 95.450, 125.663 103.100, 123.063 107.500 C 120.462 111.900, 116.714 119.100, 114.732 123.500 C 112.750 127.900, 109.980 135.028, 108.577 139.341 C 107.173 143.653, 105.327 150.628, 104.475 154.841 C 103.623 159.053, 102.534 165.875, 102.055 170 C 101.576 174.125, 101.310 182, 101.463 187.500 C 101.641 193.913, 102.528 200.370, 103.936 205.500 C 105.143 209.900, 106.954 215.975, 107.961 219 C 108.968 222.025, 111.239 228.100, 113.008 232.500 C 114.776 236.900, 120.412 249.050, 125.532 259.500 C 130.653 269.950, 138.934 285.836, 143.937 294.803 C 148.939 303.769, 158.729 320.644, 165.692 332.303 C 172.656 343.961, 192.839 376.675, 210.544 405 C 228.249 433.325, 245.607 461.546, 249.118 467.714 C 252.628 473.881, 255.725 478.925, 256 478.921 C 256.275 478.918, 259.650 473.495, 263.500 466.870 C 267.350 460.245, 276.900 444.626, 284.722 432.162 C 292.544 419.698, 303.119 402.877, 308.222 394.781 C 313.325 386.686, 320.286 375.661, 323.691 370.281 C 327.096 364.902, 333.453 354.650, 337.818 347.500 C 342.183 340.350, 348.344 330.225, 351.509 325 C 354.675 319.775, 361.103 308.750, 365.794 300.500 C 370.485 292.250, 378.706 276.725, 384.063 266 C 389.420 255.275, 395.029 243.575, 396.528 240 C 398.026 236.425, 400.737 229.408, 402.551 224.407 C 404.366 219.406, 406.798 211.326, 407.955 206.451 C 409.113 201.576, 410.322 194.418, 410.643 190.544 C 410.963 186.670, 410.736 178.700, 410.138 172.833 C 409.541 166.966, 408.331 158.678, 407.451 154.416 C 406.571 150.154, 404.490 142.579, 402.828 137.583 C 401.166 132.588, 397.673 124.225, 395.065 119 C 392.458 113.775, 388.295 106.350, 385.814 102.500 C 383.332 98.650, 377.878 91.450, 373.693 86.500 C 369.507 81.550, 363.321 75.025, 359.945 72 C 356.569 68.975, 349.957 63.742, 345.252 60.371 C 340.547 57, 331.703 51.739, 325.599 48.679 C 319.494 45.620, 310.225 41.699, 305 39.967 C 299.775 38.235, 291 35.913, 285.500 34.808 C 278.607 33.422, 270.529 32.708, 259.500 32.510 C 250.700 32.352, 240.575 32.605, 237 33.073 M 244.500 113.478 C 240.100 114.181, 233.575 116.022, 230 117.567 C 226.425 119.113, 221.250 121.800, 218.500 123.539 C 215.750 125.277, 211.456 128.680, 208.958 131.100 C 206.459 133.520, 202.564 137.975, 200.302 141 C 198.040 144.025, 194.799 149.875, 193.099 154 C 191.399 158.125, 189.378 164.573, 188.609 168.330 C 187.840 172.086, 187.350 178.611, 187.521 182.830 C 187.692 187.048, 188.538 193.536, 189.401 197.247 C 190.264 200.958, 192.581 207.254, 194.549 211.237 C 196.518 215.221, 199.241 219.938, 200.599 221.719 C 201.958 223.500, 205.416 227.272, 208.285 230.101 C 211.153 232.930, 215.862 236.759, 218.749 238.609 C 221.636 240.460, 226.603 243.070, 229.788 244.411 C 232.972 245.751, 239.160 247.526, 243.539 248.355 C 247.918 249.184, 254.650 249.714, 258.500 249.533 C 262.350 249.351, 268.498 248.498, 272.162 247.636 C 275.827 246.774, 281.481 244.783, 284.727 243.210 C 287.973 241.638, 292.625 238.974, 295.064 237.290 C 297.504 235.605, 301.844 231.814, 304.708 228.864 C 307.572 225.914, 311.202 221.700, 312.774 219.500 C 314.346 217.300, 316.799 213.025, 318.226 210 C 319.652 206.975, 321.606 201.575, 322.567 198 C 323.709 193.758, 324.316 187.853, 324.316 181 C 324.316 174.238, 323.708 168.244, 322.608 164.163 C 321.669 160.677, 319.658 155.277, 318.140 152.163 C 316.622 149.048, 314.220 144.677, 312.802 142.448 C 311.385 140.219, 307.587 135.764, 304.362 132.548 C 301.138 129.332, 296.250 125.268, 293.500 123.517 C 290.750 121.766, 285.125 118.955, 281 117.272 C 276.752 115.538, 269.853 113.731, 265.091 113.105 C 260.466 112.497, 255.741 112.045, 254.591 112.099 C 253.441 112.153, 248.900 112.774, 244.500 113.478",
                                fillColor: color,
                                fillOpacity: 1,
                                stroke: 0,
                                strokeWeight: 1,
                                rotation: 0,
                                scale: 0.08,
                                anchor: new google.maps.Point(250, 400),
                            };
                            return svgMarker;
                        }

                        function MapCircle(lat, lng, radius = 1000) {
                            var circle = new google.maps.Circle({
                                map: map,
                                center: {
                                    lat: lat,
                                    lng: lng,
                                },
                                radius: radius,
                                strokeColor: "#5A84C0",
                                fillColor: "#ACC8F2",
                            });
                            return circle;
                        }

                        <?php
                        foreach ($address_list as $al) {

                            if ($al->image == 'pin.png') {
                                echo "
                                var radius = {$al->radius};
                                var img = svgIcon('" . $al->color . "');
                            addMarker({
                                lat: {$al->latitude},
                                lng: {$al->longitude}
                            },img);
                            MapCircle({$al->latitude},{$al->longitude},{$al->radius}*1000);
                            ";
                            } else {
                                $img = $al->img_src;
                                echo "
                            var img = '" . $img . "';
                            addMarker({
                                lat: {$al->latitude},
                                lng: {$al->longitude}
                            },img);
                            MapCircle({$al->latitude},{$al->longitude},{$al->radius}*1000);
                            ";
                            }
                        }
                        ?>

                        // var mappers = jQuery(".mapper");
                        // var mapper_length = mappers.length;
                        document.querySelectorAll('.mapper').forEach(item => {
                            item.addEventListener('click', event => {
                                //handle click
                                var lat = (item.getAttribute('data-lat'));
                                var lng = (item.getAttribute('data-lng'));
                                map.panTo(map.getPosition({
                                    lat: lat,
                                    lng: lng,
                                }));
                                map.setZoom(13);
                            })
                        })



                        initAutocomplete();
                    }
                    window.initMap = initMap;
                </script>
                <script>
                    function initAutocomplete() {
                        var input = document.getElementById("address");
                        var autocomplete = new google.maps.places.Autocomplete(input);

                        autocomplete.setFields(["address_components", "geometry", "icon", "name", "place_id"]);

                        var infowindow = new google.maps.InfoWindow();

                        var infowindowContent = document.getElementById("infowindow-content");

                        infowindow.setContent(infowindowContent);

                        autocomplete.addListener("place_changed", function() {
                            infowindow.close();

                            place = autocomplete.getPlace();
                            var latitude = place.geometry.location.lat();
                            var longitude = place.geometry.location.lng();

                            jQuery("#latitude").val(latitude);
                            jQuery("#longitude").val(longitude);

                            if (!place.geometry) {
                                window.alert(
                                    "No details available for input: '" + place.name + "'"
                                );
                                return;
                            }

                            var address = "";
                            if (place.address_components) {
                                address = [
                                    (place.address_components[0] &&
                                        place.address_components[0].short_name) ||
                                    "",
                                    (place.address_components[1] &&
                                        place.address_components[1].short_name) ||
                                    "",
                                ].join(" ");
                            }

                            for (a = 0; a < place.address_components.length; a++) {
                                if (
                                    place.address_components[a].types[0] ==
                                    "administrative_area_level_1"
                                ) {
                                    stateValue = place.address_components[a].long_name;
                                    stateCode = place.address_components[a].short_name;
                                }
                            }

                        });
                    }
                </script>
            </div>
        </div>
    </div>
</div>
<script>
    jQuery('#img-upload').click(function(e) {
        e.preventDefault();
        var upload = wp.media({
                title: 'Choose Image', //Title for Media Box
                multiple: false //For limiting multiple image
            })
            .on('select', function() {
                var select = upload.state().get('selection');
                var attach = select.first().toJSON();
                // console.log(attach.id);
                // console.log(attach.url);
                jQuery('#img-src').attr('src', attach.url);
                jQuery('#img-src').css('display', "block");
                jQuery("#image_selector").val(attach.url);
            })
            .open();
    });
</script>