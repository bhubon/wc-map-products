<?php
/*
 * Plugin Name:       Map Location Marker
 * Plugin URI:        https://thedevnil.com
 * Description:       Dynamic markers and location with google map
 * Version:           1.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            BHUBON NIL
 * Author URI:        https://thedevnil.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Update URI:        https://example.com/my-plugin/
 * Text Domain:       map-location-marker
 * Domain Path:       /languages
 */

require_once plugin_dir_path(__FILE__) . 'class/map-location-manager.php';

class Map_Location_Marker {
    public function __construct() {
        new Map_Location_Manager();
        define("TEXTDOMAIN", 'map-location-marker');
        register_activation_hook(__FILE__, [$this, 'mlm_create_table']);
    }
    public function mlm_create_table() {
        global $table_prefix, $wpdb;
        $address_table = $table_prefix . 'mlm_map_manager';
        $charset_collate = $wpdb->get_charset_collate();
        $schema = "CREATE TABLE IF NOT EXISTS `{$address_table}` (
            `id` int NOT NULL AUTO_INCREMENT,
            `f_name` varchar(255) NOT NULL,
            `l_name` varchar(255) NOT NULL,
            `address` text NOT NULL,
            `zip_code` varchar(255) NOT NULL,
            `landline` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
            `mobile` varchar(255) NOT NULL,
            `email` varchar(255) NOT NULL,
            `link` varchar(255) NOT NULL,
            `image` varchar(500) NOT NULL,
            `color` varchar(255) NOT NULL,
            `img_src` varchar(255) NOT NULL,
            `radius` varchar(255) NOT NULL,
            `latitude` varchar(500) NOT NULL,
            `longitude` varchar(500) NOT NULL,
            `notes` text NOT NULL,
            `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
          ) $charset_collate ;
          ";

          if(!function_exists('dbDelta')){
            require_once ABSPATH.'wp-admin/includes/upgrade.php';
          }
          dbDelta($schema);
    }
}
function mlm_init() {
    new Map_Location_Marker();
}
mlm_init();
