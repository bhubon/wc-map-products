; (function ($) {
    $(document).ready(function () {
        $("#address_form").on('submit', function (e) {
            e.preventDefault();
            var btn = $("#address_submit_btn");
            var form_data = $(this).serialize();

            btn.html("Submitting...")
            btn.attr("disabled", true);

            jQuery.post(mlm_object.ajax_url, form_data, function (response) {
                btn.html("Submit")
                btn.attr("disabled", false);
                if (response.status == 1) {
                    $("#address_form").trigger('reset');
                    $(".address-alert").html(response.msg);
                    window.location.reload();
                } else {
                    $(".address-alert").html(response.msg);
                }
            });
        });

        $("#search_btn").on('click', function () {
            var query = $("#search_q").val();
            var action = 'mlm_search_query';
            var container = jQuery('.address-details-body');
            var loader = jQuery(".lds-ring");
            container.html('<div style="display:inline-block;" class="lds-ring"><div></div><div></div> <div></div> <div></div></div>');
            $.post(mlm_object.ajax_url, { query, action }, function (response) {
                // console.log(response);
                container.html(response);
            });
        });

        $("#images").on('change', function () {
            if ($(this).val() == 'pin.png') {
                $("#color_picker_wrap").css("display", "block");
                $("#image_picker").css("display", 'none');
            } else if ($(this).val() == 'image') {
                $("#color_picker_wrap").css("display", 'none');
                $("#image_picker").css("display", 'block');
            } else {
                $("#color_picker_wrap").css("display", 'none');
                $("#image_picker").css("display", 'block');
            }
        });
        // show color picker
        // $("#images").on("change",function(){
        //     if($(this).val() == 'pin.png'){
        //         $("#color_picker_wrap").css("display","block");
        //     }else{
        //         $("#color_picker_wrap").css("display","none");
        //     }
        // });
    });
})(jQuery);
var $ = jQuery;
function getAddressData(me) {
    var address_id = me;
    var btn = $('.edit-address_' + me);
    btn.html("Geeting Data...");
    jQuery.post(mlm_object.ajax_url, { address_id: address_id, action: 'get_address_by_id' }, function (response) {
        if (response.id) {
            $("#address_form #f_name").val(response.f_name);
            $("#address_form #l_name").val(response.l_name);
            $("#address_form #address").val(response.address);
            $("#address_form #zip_code").val(response.zip_code);
            $("#address_form #landline").val(response.landline);
            $("#address_form #mobile").val(response.mobile);
            $("#address_form #email").val(response.email);
            $("#address_form #images").val(response.image);
            $("#address_form #color_picker").val(response.color);
            if (response.image == "pin.png") {
                $("#address_form #color_picker_wrap").css("display", "block");
                $("#address_form #image_picker").css("display", "none");
            } else {
                $("#address_form #img-src").attr("src", response.image_selector);
                $("#address_form #img-src").css("display", "block");
                $("#address_form #image_picker").css("display", "block");
                $("#address_form #color_picker_wrap").css("display", "none");
            }
            $("#address_form #radius").val(response.radius);
            $("#address_form #link").val(response.link);
            $("#address_form #latitude").val(response.latitude);
            $("#address_form #longitude").val(response.longitude);
            $("#address_form #image_selector").val(response.image_selector);

            $("#address_form #note").val(response.notes);
            $("#address_form #company_name").val(response.company_name);


            $("#address_form #address_submit_btn").html("Update");
            $("#address_form").append("<input type='hidden' name='mode' value='edit'>");
            $("#address_form").append("<input type='hidden' name='address_id' value='" + address_id + "'>");
            btn.html("Bearbeiten");
        } else {
            alert("Something Went Wrong. Try again later!");
        }
    });
}
function deleteAddress(id) {
    if (confirm("Are you sure to delete?") == true) {
        var btn = $(".delete-address_" + id);
        btn.html("Deletting...");
        jQuery.post(mlm_object.ajax_url, { id: id, action: 'delete_address' }, function (response) {
            if (response.status == true) {
                btn.html("Deleted. Redirecting...");
                window.location.reload();
            } else {
                alert(response.msg);
            }
        });
    }
}